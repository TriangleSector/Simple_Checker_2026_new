1. **Run:** Launch `Simple checker.exe` and select your target module (e.g., Steam).
2. **Load Data:** Place your validation lists in the `input/` directory.
3. **Set Proxies:** Add your proxy list to `proxies.txt` for anonymous auditing. 


